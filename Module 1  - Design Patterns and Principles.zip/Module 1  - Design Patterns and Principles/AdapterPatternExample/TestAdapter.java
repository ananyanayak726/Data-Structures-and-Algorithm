interface PaymentProcessor {
    void processPayment(PaymentDetails paymentDetails);
}

class StripeGateway {
    void charge(StripePaymentRequest request) {
        System.out.println("Processing payment with Stripe: " + request);
    }
}

class PaypalGateway {
    void makePayment(PaypalPaymentRequest request) {
        System.out.println("Processing payment with Paypal: " + request);
    }
}

class StripeAdapter implements PaymentProcessor {
    private StripeGateway stripeGateway;

    public StripeAdapter(StripeGateway stripeGateway) {
        this.stripeGateway = stripeGateway;
    }

    @Override
    public void processPayment(PaymentDetails   
 paymentDetails) {
        StripePaymentRequest request = new StripePaymentRequest(
            paymentDetails.getCardNumber(),
            paymentDetails.getExpiryDate(),
            paymentDetails.getCvv(),
            paymentDetails.getAmount()
        );
        stripeGateway.charge(request);
    }
}

class PaypalAdapter implements PaymentProcessor {
    private PaypalGateway paypalGateway;

    public PaypalAdapter(PaypalGateway paypalGateway) {
        this.paypalGateway = paypalGateway;
    }

    @Override
    public void processPayment(PaymentDetails   
 paymentDetails) {
        PaypalPaymentRequest request = new PaypalPaymentRequest(
            paymentDetails.getEmail(),
            paymentDetails.getAmount()
        );
        paypalGateway.makePayment(request);
    }
}

class PaymentDetails {
    private String cardNumber;
    private String expiryDate;
    private String cvv;
    private double amount;
    private String email;

    // Constructor with required fields
    public PaymentDetails(String cardNumber, String expiryDate, String cvv, double amount) {
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
        this.amount = amount;   

    }

    // Constructor for PayPal
    public PaymentDetails(String email, double amount) {
        this.email = email;
        this.amount = amount;
    }

    // Getters and setters
    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;   

    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getCvv()   
 {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String   
 getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;   

    }
}

class StripePaymentRequest {
    private String cardNumber;
    private String expiryDate;
    private String cvv;
    private double amount;

    public StripePaymentRequest(String cardNumber, String expiryDate, String cvv, double amount) {
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
        this.amount = amount;   

    }

    @Override
    public String toString() {
        return "StripePaymentRequest{" +
                "cardNumber='" + cardNumber + '\'' +
                ", expiryDate='" + expiryDate + '\'' +
                ", cvv='" + cvv + '\'' +
                ", amount=" + amount +
                '}';
    }
}

class PaypalPaymentRequest {
    private String email;
    private double amount;

    public PaypalPaymentRequest(String email, double amount) {
        this.email = email;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "PaypalPaymentRequest{" +
                "email='" + email + '\'' +
                ", amount=" + amount +
                '}';
    }
}

class TestAdapter {
    public static void main(String[] args) {
        PaymentDetails cardPayment = new PaymentDetails("1234567890123456", "12/25", "123", 100.0);
        PaymentDetails paypalPayment = new PaymentDetails("user@example.com", 50.0);

        StripeGateway stripeGateway = new StripeGateway();
        StripeAdapter stripeAdapter = new StripeAdapter(stripeGateway);
        stripeAdapter.processPayment(cardPayment);

        PaypalGateway paypalGateway = new PaypalGateway();
        PaypalAdapter paypalAdapter = new PaypalAdapter(paypalGateway);
        paypalAdapter.processPayment(paypalPayment);
    }
}

