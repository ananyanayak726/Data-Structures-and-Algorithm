class Computer {
    private String cpu;
    private String ram;
    private String storage;
    private boolean isGraphicsCardEnabled;
    private boolean isBluetoothEnabled;

    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
        this.isGraphicsCardEnabled = builder.isGraphicsCardEnabled;
        this.isBluetoothEnabled = builder.isBluetoothEnabled;
    }

    public String getCpu() {
        return cpu;
    }

    public String getRam() {
        return ram;
    }

    public String getStorage() {
        return storage;
    }

    public boolean isGraphicsCardEnabled() {
        return isGraphicsCardEnabled;
    }

    public boolean isBluetoothEnabled() {
        return isBluetoothEnabled;
    }

    public static class Builder {
        private String cpu;
        private String ram;
        private String storage;
        private boolean isGraphicsCardEnabled;
        private boolean isBluetoothEnabled;

        public Builder setCpu(String cpu) {
            this.cpu = cpu;
            return this;
        }

        public Builder setRam(String ram) {
            this.ram = ram;
            return this;
        }

        public Builder setStorage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder setGraphicsCardEnabled(boolean isGraphicsCardEnabled) {
            this.isGraphicsCardEnabled = isGraphicsCardEnabled;
            return this;
        }

        public Builder setBluetoothEnabled(boolean isBluetoothEnabled) {
            this.isBluetoothEnabled = isBluetoothEnabled;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }
}
class ComputerBuilderTest {
    public static void main(String[] args) {
        Computer computer1 = new Computer.Builder()
               .setCpu("Intel Core i5")
               .setRam("8GB")
               .setStorage("1TB")
               .setGraphicsCardEnabled(true)
               .setBluetoothEnabled(true)
               .build();

        System.out.println("Computer 1 Configuration:");
        System.out.println("CPU: " + computer1.getCpu());
        System.out.println("RAM: " + computer1.getRam());
        System.out.println("Storage: " + computer1.getStorage());
        System.out.println("Graphics Card Enabled: " + computer1.isGraphicsCardEnabled());
        System.out.println("Bluetooth Enabled: " + computer1.isBluetoothEnabled());

        Computer computer2 = new Computer.Builder()
               .setCpu("AMD Ryzen 7")
               .setRam("16GB")
               .setStorage("2TB")
               .setGraphicsCardEnabled(false)
               .setBluetoothEnabled(true)
               .build();

        System.out.println("\nComputer 2 Configuration:");
        System.out.println("CPU: " + computer2.getCpu());
        System.out.println("RAM: " + computer2.getRam());
        System.out.println("Storage: " + computer2.getStorage());
        System.out.println("Graphics Card Enabled: " + computer2.isGraphicsCardEnabled());
        System.out.println("Bluetooth Enabled: " + computer2.isBluetoothEnabled());
    }
}