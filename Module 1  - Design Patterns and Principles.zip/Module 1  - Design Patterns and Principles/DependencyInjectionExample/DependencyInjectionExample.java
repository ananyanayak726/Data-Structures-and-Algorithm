import java.util.HashMap;
import java.util.Map;

public class DependencyInjectionExample {
    static class Customer {
        private int id;
        private String name;

        public Customer(int id, String name) {
            this.id = id;
            this.name = name;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return 
 name;
        }
    }

    interface CustomerRepository {
        Customer findCustomerById(int id);
    }

    static class CustomerRepositoryImpl implements CustomerRepository {
        private Map<Integer, Customer> customers = new HashMap<>();

        public CustomerRepositoryImpl() {
            // Sample data
            customers.put(1, new Customer(1, "John Doe"));
            customers.put(2, new Customer(2, "Jane Smith"));
        }

        @Override
        public Customer findCustomerById(int id) {
            return customers.get(id);
        }
    }

    static class CustomerService {
        private CustomerRepository customerRepository;

        public CustomerService(CustomerRepository customerRepository)  
 {
            this.customerRepository = customerRepository;
        }

        public Customer  
 findCustomerById(int id) {
            return customerRepository.findCustomerById(id);
        }
    }

    public static void main(String[] args) {
        CustomerRepository customerRepository = new CustomerRepositoryImpl();
        CustomerService customerService = new CustomerService(customerRepository);

        Customer customer = customerService.findCustomerById(1);
        System.out.println(customer.getName()); // Output: John Doe
    }
}