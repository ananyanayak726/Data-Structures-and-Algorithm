interface PaymentStrategy {
    void pay(double amount);
}

class CreditCardPayment implements PaymentStrategy {
    @Override
    public void pay(double amount) {
        System.out.println(amount 
 + " paid using Credit Card");
    }
}

class PayPalPayment implements PaymentStrategy {
    @Override
    public void pay(double amount) {
        System.out.println(amount 
 + " paid using PayPal");
    }
}

class PaymentContext {
    private PaymentStrategy paymentStrategy;

    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy 
 = paymentStrategy;
    }

    public void pay(double amount) {
        paymentStrategy.pay(amount); 

    }
}

public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext();

        // Pay by credit card
        paymentContext.setPaymentStrategy(new CreditCardPayment());
        paymentContext.pay(200.0);

        // Pay by PayPal
        paymentContext.setPaymentStrategy(new PayPalPayment());
        paymentContext.pay(150.0);
    }
}
