import java.util.ArrayList;
import java.util.List;

interface Stock {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
}

interface Observer {
    void update(double price);
}

class StockMarket implements Stock {
    private double price;
    private List<Observer> observers;

    public StockMarket() {
        observers = new ArrayList<>();
    }

    public void setPrice(double price) {
        this.price = price;
        notifyObservers();
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(price); 

        }
    }
}

class MobileApp implements Observer {
    @Override
    public void update(double price) {
        System.out.println("MobileApp: Price updated to " + price);
    }
}

class WebApp implements Observer {
    @Override
    public void update(double price) {
        System.out.println("WebApp: Price updated to " + price);
    }
}
public class ObserverPatternExample {
	  public static void main(String[] args) {
	        StockMarket stockMarket = new StockMarket();

	        Observer mobileApp = new MobileApp();
	        Observer webApp = new WebApp();

	        stockMarket.registerObserver(mobileApp);
	        stockMarket.registerObserver(webApp);

	        stockMarket.setPrice(100.0);
	        stockMarket.setPrice(200.0);

	        // Remove an observer
	        stockMarket.removeObserver(webApp);

	        stockMarket.setPrice(300.0);
	    }
	

}
