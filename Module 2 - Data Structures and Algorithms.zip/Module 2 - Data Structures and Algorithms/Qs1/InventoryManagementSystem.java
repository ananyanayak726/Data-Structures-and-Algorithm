import java.util.HashMap;
import java.util.Scanner;

class Product {
    int productId;
    String productName;
    int quantity;
    double price;

    Product(int id, String name, int qty, double p) {
        productId = id;
        productName = name;
        quantity = qty;
        price = p;
    }
}

class Inventory {
    HashMap<Integer, Product> products;

    Inventory() {
        products = new HashMap<>();
    }

    void addProduct() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter product name: ");
        String productName = scanner.nextLine();

        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();

        System.out.print("Enter price: ");
        double price = scanner.nextDouble();  


        Product product = new Product(productId, productName, quantity, price);
        products.put(productId, product);
        System.out.println("Product added successfully.");
    }

    void updateProduct() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter product ID to update: ");
        int productId = scanner.nextInt();

        Product product = products.get(productId);
        if (product != null) {
            System.out.print("Enter new quantity: ");
            int newQuantity = scanner.nextInt();

            System.out.print("Enter new price: ");
            double newPrice = scanner.nextDouble();  


            product.quantity = newQuantity;
            product.price = newPrice;
            System.out.println("Product updated successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    void deleteProduct() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();

        if (products.remove(productId) != null) {
            System.out.println("Product deleted successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    void displayInventory() {
        System.out.println("Inventory:");
        for (Product product : products.values()) {
            System.out.println("Product ID: " + product.productId + ", Name: " + product.productName + ", Quantity: " + product.quantity + ", Price: $" + product.price);
        }
    }
}

class InventoryManagementSystem {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        Scanner scanner = new Scanner(System.in); 

        int choice;

        do {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add product");
            System.out.println("2. Update product");
            System.out.println("3. Delete product");
            System.out.println("4. Display inventory");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    inventory.addProduct();
                    break;
                case 2:
                    inventory.updateProduct();
                    break;
                case 3:
                    inventory.deleteProduct();
                    break;
                case 4:
                    inventory.displayInventory();
                    break;
                case 5:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 5);
    }
}
