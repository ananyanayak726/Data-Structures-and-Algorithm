import java.util.Arrays;
import java.util.Scanner;

class Product implements Comparable<Product> {
    int productId;
    String productName;
    String category;

    Product(int id, String name, String cat) {
        productId = id;
        productName = name;
        category = cat;
    }

    @Override
    public int compareTo(Product other) {
        return Integer.compare(productId, other.productId);
    }
}

public class Search {
    public static int linearSearch(Product[] products, Product target) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].equals(target)) {
                return i;
            }
        }
        return -1; // Not found
    }

    public static int binarySearch(Product[] products, Product target) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].compareTo(target);
            if (comparison == 0) {
                return mid;
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; 
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of products: ");
        int n = scanner.nextInt();


        Product[] products = new Product[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Enter product " + (i + 1) + " details:");
            System.out.print("Product ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Product name: ");
            String name = scanner.nextLine();
            System.out.print("Product category: ");
            String category = scanner.nextLine();

            products[i] = new Product(id, name, category);
        }

        Arrays.sort(products);

        System.out.print("Enter the product ID to search: ");
        int targetId = scanner.nextInt();
        Product target = new Product(targetId, "", "");

        int indexLinear = linearSearch(products, target);
        int indexBinary = binarySearch(products, target);

        if (indexLinear != -1) {
            System.out.println("Product found at index (linear search): " + indexLinear);
        } else {
            System.out.println("Product not found using linear search");
        }

        if (indexBinary != -1) {
            System.out.println("Product found at index (binary search): " + indexBinary);
        } else {
            System.out.println("Product not found using binary search");
        }
    }
}
