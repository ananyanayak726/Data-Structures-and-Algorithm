import java.util.Arrays;

class Order implements Comparable<Order> {
    int orderId;
    String customerName;
    double totalPrice;

    Order(int id, String name, double price) {
        orderId = id;
        customerName = name;
        totalPrice = price;
    }

    @Override
    public int compareTo(Order other) {
        return Double.compare(totalPrice, other.totalPrice);
    }
}

public class OrderSorting {
    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].totalPrice > orders[j + 1].totalPrice) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].totalPrice;
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (orders[j].totalPrice < pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    public static void mergeSort(Order[] orders, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSort(orders, left, mid);
            mergeSort(orders, mid + 1, right);
            merge(orders, left, mid, right);
        }
    }

    private static void merge(Order[] orders, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        Order[] leftArray = new Order[n1];
        Order[] rightArray = new Order[n2];

        System.arraycopy(orders, left, leftArray, 0, n1);
        System.arraycopy(orders, mid + 1, rightArray, 0, n2);

        int i = 0, j = 0, k = left;

        while (i < n1 && j < n2) {
            if (leftArray[i].totalPrice <= rightArray[j].totalPrice) {
                orders[k] = leftArray[i];
                i++;
            } else {
                orders[k] = rightArray[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            orders[k] = leftArray[i];
            i++;
            k++;
        }

        while (j < n2) {
            orders[k] = rightArray[j];
            j++;
            k++;
        }
    }

    public static void main(String[] args) {
        // ... (code to create and populate an Order array)

        // Example usage:
        Order[] orders = {
            new Order(1, "Customer A", 100.0),
            new Order(2, "Customer B", 250.0),
            // ... more orders
        };

        // Bubble Sort
        bubbleSort(orders);

        // Quick Sort
        quickSort(orders, 0, orders.length - 1);

        // Merge Sort
        mergeSort(orders, 0, orders.length - 1);

        // Print the sorted orders
        for (Order order : orders) {
            System.out.println(order.orderId + ", " + order.customerName + ", $" + order.totalPrice);
        }
    }
}

