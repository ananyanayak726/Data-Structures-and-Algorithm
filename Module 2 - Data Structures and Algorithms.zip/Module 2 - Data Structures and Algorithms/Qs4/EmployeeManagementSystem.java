public class EmployeeManagementSystem {
    static class Employee {
        int employeeId;
        String name;
        String position;
        double salary;

        Employee(int employeeId, String name, String position, double salary) {
            this.employeeId = employeeId;
            this.name = name;
            this.position = position;
            this.salary = salary;
        }
    }

    Employee[] employees;
    int count;

    EmployeeManagementSystem(int size) {
        employees = new Employee[size];
        count = 0;
    }

    void addEmployee(Employee employee) {
        if (count < employees.length) {
            employees[count] = employee;
            count++;
        } else {
            System.out.println("Array is full");
        }
    }

    Employee searchEmployee(int employeeId) {
        for (Employee employee : employees) {
            if (employee != null && employee.employeeId == employeeId) {
                return employee;
            }
        }
        return null;
    }

    void traverseEmployees() {
        for (Employee employee : employees) {
            if (employee != null) {
                System.out.println("ID: " + employee.employeeId + ", Name: " + employee.name + ", Position: " + employee.position + ", Salary: " + employee.salary);
            }
        }
    }

    boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i] != null && employees[i].employeeId == employeeId) {
                // Simple approach: Overwrite with the last element
                employees[i] = employees[count - 1];
                employees[count - 1] = null;
                count--;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);

        // Add employees
        system.addEmployee(new Employee(1, "John Doe", "Manager", 50000));
        system.addEmployee(new Employee(2, "Jane Smith", "Developer", 40000));
        system.addEmployee(new Employee(3, "Bob Johnson", "Designer", 35000));

        // Search for an employee
        Employee foundEmployee = system.searchEmployee(2);
        if (foundEmployee != null) {
            System.out.println("Found employee: " + foundEmployee.name);
        } else {
            System.out.println("Employee not found");
        }

        // Traverse employees
        system.traverseEmployees();

        // Delete an employee
        system.deleteEmployee(2);

        // Traverse employees again
        system.traverseEmployees();
    }
}
