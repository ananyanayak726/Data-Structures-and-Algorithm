import java.util.Arrays;

public class Library {
    static class Book {
        int bookId;
        String title;
        String author;

        Book(int bookId, String title, String author) {
            this.bookId = bookId;
            this.title = title;
            this.author = author;
        }
    }

    Book[] books;

    Library(Book[] books) {
        this.books = books;
    }

    // Linear search by title
    Book findBookByTitleLinear(String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    // Binary search by title (assuming books are sorted by title)
    Book findBookByTitleBinary(String title) {
        int left = 0, right = books.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].title.compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "The Lord of the Rings", "J.R.R. Tolkien"),
            new Book(2, "To Kill a Mockingbird", "Harper Lee"),
            new Book(3, "1984", "George Orwell")
        };

        Library library = new Library(books);

        // Linear search example
        Book book1 = library.findBookByTitleLinear("To Kill a Mockingbird");
        if (book1 != null) {
            System.out.println("Found book: " + book1.title);
        } else {
            System.out.println("Book not found");
        }

        // Binary search example (assuming books are sorted)
        Arrays.sort(books, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));
        Book book2 = library.findBookByTitleBinary("1984");
        if (book2 != null) {
            System.out.println("Found book: " + book2.title);
        } else {
            System.out.println("Book not found");
        }
    }
}
